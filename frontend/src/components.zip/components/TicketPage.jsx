// src/pages/TicketPage.jsx
import React, { useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import "../styles/TicketPage.css";

const TicketPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { booking, totalPrice } = location.state || {};
  const ticketRef = useRef();

  if (!booking) {
    return <h2 style={{ textAlign: "center" }}>No ticket details found.</h2>;
  }

  // ✅ Download Ticket as PDF
  const downloadTicket = async () => {
    const canvas = await html2canvas(ticketRef.current);
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a5");
    const width = pdf.internal.pageSize.getWidth();
    const height = (canvas.height * width) / canvas.width;
    pdf.addImage(imgData, "PNG", 0, 0, width, height);
    pdf.save(`ConcertTicket_${booking.id}.pdf`);
  };

  return (
    <div className="ticket-container">
      <div className="ticket" ref={ticketRef}>
        <h2>🎟️ Concert Ticket</h2>
        <div className="ticket-info">
          <p><strong>Booking ID:</strong> {booking.id}</p>
          <p><strong>Concert:</strong> {booking.concert?.title || "Live Concert"}</p>
          <p><strong>User Email:</strong> {booking.userEmail || "anonymous@example.com"}</p>
          <p><strong>Seats:</strong> {booking.seats?.join(", ") || "N/A"}</p>
          <p><strong>Total Paid:</strong> ₹{totalPrice}</p>
        </div>

        <div className="ticket-footer">
          <img
            src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=Booking-${booking.id}`}
            alt="QR Code"
          />
          <p>Scan for verification</p>
        </div>
      </div>

      <div className="ticket-actions">
        <button className="download-btn" onClick={downloadTicket}>
          ⬇️ Download Ticket (PDF)
        </button>
        <button className="home-btn" onClick={() => navigate("/")}>
          🏠 Go to Home Page
        </button>
      </div>
    </div>
  );
};

export default TicketPage;
