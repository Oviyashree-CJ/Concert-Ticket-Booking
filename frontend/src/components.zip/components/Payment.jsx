// ✅ src/pages/Payment.jsx
import React, { useState } from "react";
import { motion } from "framer-motion";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import "../styles/Payment.css";

const Payment = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // ✅ Extract booking info passed from SeatBooking
  const { bookingId, concertId, concertTitle, tickets, seats, totalPrice } = location.state || {};

  // ✅ Logged-in user email
  const userEmail = localStorage.getItem("userEmail") || "guest@example.com";


  const [paymentMethod, setPaymentMethod] = useState("card");
  const [cardDetails, setCardDetails] = useState({
    name: "",
    number: "",
    expiry: "",
    cvv: "",
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [success, setSuccess] = useState(false);

  // ✅ Handle payment
  const handlePayment = async (e) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      // ✅ Step 1: Update booking status to "Paid"
      const bookingResponse = await axios.put(
        `http://localhost:8080/api/bookings/${bookingId}`,
        {
          concertId,
          concertTitle,
          tickets: tickets || seats?.join(", ") || "Seat 1",
          totalPrice,
          userEmail,
          status: "Paid",
        }
      );

      const savedBooking = bookingResponse.data;
      console.log("✅ Booking updated:", savedBooking);

      // ✅ Step 2: Record payment
      const paymentResponse = await axios.post("http://localhost:8080/api/payments", {
        bookingId: savedBooking.id,
        amount: totalPrice,
        method: paymentMethod,
      });

      console.log("💳 Payment success:", paymentResponse.data);

      // ✅ Step 3: Confirm booking
      await axios.put(`http://localhost:8080/api/bookings/${savedBooking.id}`, {
        ...savedBooking,
        status: "Confirmed",
        paymentId:
          paymentResponse.data?.paymentId ||
          "PAY-" + Math.floor(Math.random() * 100000),
      });

      // ✅ Step 4: Success popup
      setTimeout(() => {
        setIsProcessing(false);
        setSuccess(true);
      }, 1500);
    } catch (err) {
      console.error("❌ Payment or booking failed:", err);
      alert("Payment failed or booking not saved. Please try again.");
      setIsProcessing(false);
    }
  };

  // ✅ After success → go to ticket page
  const handleSuccessRedirect = () => {
    navigate("/ticket", {
      state: { bookingId, concertId, concertTitle, totalPrice, tickets },
    });
  };

  return (
    <motion.div
      className="payment-container"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <motion.div
        className="payment-card"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <h1 className="payment-title">💳 Secure Payment</h1>

        {/* ✅ Booking Summary */}
        <div className="summary-box">
          <h3>🎟️ Booking Summary</h3>
          <p>
            Booking ID: <strong>{bookingId || "Generating..."}</strong>
          </p>
          <p>
            Seats Selected:{" "}
            <strong>{tickets || seats?.join(", ") || "Not Available"}</strong>
          </p>
          <p>
            Total Price: <strong>₹{totalPrice || "N/A"}</strong>
          </p>
          <hr />
          <p>
            Event: <strong>{concertTitle || "Concert Night 2025"}</strong>
          </p>
          <p>
            Location: <strong>Chennai Stadium</strong>
          </p>
          <p>
            Date: <strong>25 Dec 2025</strong>
          </p>
        </div>

        {/* ✅ Payment Methods */}
        <div className="payment-methods">
          <h3>Choose Payment Method</h3>
          <div className="method-buttons">
            <button
              className={paymentMethod === "card" ? "active" : ""}
              onClick={() => setPaymentMethod("card")}
            >
              💳 Card
            </button>
            <button
              className={paymentMethod === "upi" ? "active" : ""}
              onClick={() => setPaymentMethod("upi")}
            >
              📱 UPI
            </button>
            <button
              className={paymentMethod === "wallet" ? "active" : ""}
              onClick={() => setPaymentMethod("wallet")}
            >
              💰 Wallet
            </button>
          </div>
        </div>

        {/* ✅ Card Payment Form */}
        {paymentMethod === "card" && (
          <motion.form
            className="card-form"
            onSubmit={handlePayment}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <input
              type="text"
              placeholder="Cardholder Name"
              value={cardDetails.name}
              onChange={(e) =>
                setCardDetails({ ...cardDetails, name: e.target.value })
              }
              required
            />
            <input
              type="text"
              placeholder="Card Number"
              maxLength="16"
              value={cardDetails.number}
              onChange={(e) =>
                setCardDetails({ ...cardDetails, number: e.target.value })
              }
              required
            />
            <div className="card-row">
              <input
                type="text"
                placeholder="MM/YY"
                maxLength="5"
                value={cardDetails.expiry}
                onChange={(e) =>
                  setCardDetails({ ...cardDetails, expiry: e.target.value })
                }
                required
              />
              <input
                type="password"
                placeholder="CVV"
                maxLength="3"
                value={cardDetails.cvv}
                onChange={(e) =>
                  setCardDetails({ ...cardDetails, cvv: e.target.value })
                }
                required
              />
            </div>

            <motion.button
              type="submit"
              className="pay-btn"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              disabled={isProcessing}
            >
              {isProcessing ? "Processing..." : "Pay ₹" + totalPrice}
            </motion.button>
          </motion.form>
        )}

        {/* ✅ UPI Payment Form */}
        {paymentMethod === "upi" && (
          <motion.form
            className="upi-form"
            onSubmit={handlePayment}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <input type="text" placeholder="Enter UPI ID (e.g. name@upi)" required />
            <motion.button
              type="submit"
              className="pay-btn"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              disabled={isProcessing}
            >
              {isProcessing ? "Processing..." : "Pay ₹" + totalPrice}
            </motion.button>
          </motion.form>
        )}

        {/* ✅ Wallet Payment Form */}
        {paymentMethod === "wallet" && (
          <motion.form
            className="wallet-form"
            onSubmit={handlePayment}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <select required>
              <option value="">Select Wallet</option>
              <option value="Paytm">Paytm</option>
              <option value="PhonePe">PhonePe</option>
              <option value="GooglePay">Google Pay</option>
            </select>
            <motion.button
              type="submit"
              className="pay-btn"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              disabled={isProcessing}
            >
              {isProcessing ? "Processing..." : "Pay ₹" + totalPrice}
            </motion.button>
          </motion.form>
        )}
      </motion.div>

      {success && (
        <motion.div
          className="success-popup"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
        >
          <h2>🎉 Payment Successful!</h2>
          <p>Your booking has been confirmed. See you at the concert! 🎶</p>
          <button onClick={handleSuccessRedirect}>View Your Ticket 🎟️</button>
        </motion.div>
      )}
    </motion.div>
  );
};

export default Payment;
